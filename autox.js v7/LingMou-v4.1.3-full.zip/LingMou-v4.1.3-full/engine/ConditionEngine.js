/**
 * 灵眸 v4.1.3
 * ConditionEngine
 */


var ConditionEngine=(function(){

"use strict";


var list={};

var index=0;



function id(){

index++;

return "condition_"
+index;

}




function safe(fn){


try{


var t=Date.now();


var result=fn();


return {


matched:!!result,

cost:
Date.now()-t


};


}
catch(e){


return {


matched:false,

error:String(e)


};


}


}




return {


init:function(){

log(
"[Condition] ready"
);

},



register:function(name,fn){


var k=id();


list[k]={

name:name,

fn:fn

};


return k;


},



check:function(k){


if(!list[k]){

return {

matched:false

};

}


return safe(
list[k].fn
);


},



image:function(img){


return safe(function(){


return !!images.findImage(
captureScreen(),
img
);


});


},



text:function(txt){


return safe(function(){


return paddle.ocrText(
captureScreen()
)
.indexOf(txt)>=0;


});


},



time:function(fn){


return safe(fn);


}



};



})();


module.exports=ConditionEngine;