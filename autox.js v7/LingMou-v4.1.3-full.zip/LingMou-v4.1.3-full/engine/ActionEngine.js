/**
 * 灵眸 v4.1.3
 * ActionEngine
 */


var ActionEngine=(function(){

"use strict";


var retryCount=3;



function execute(fn){


var error=null;


for(
var i=0;
i<retryCount;
i++
){


try{


fn();


return {

success:true,

retry:i

};


}
catch(e){


error=e;


}


}



return {

success:false,

error:String(error)

};


}




return {


init:function(cfg){


if(cfg && cfg.retry){

retryCount=
cfg.retry;

}


},



click:function(x,y){


return execute(function(){


click(
x,
y
);


});


},



longClick:function(x,y,time){


return execute(function(){


longClick(
x,
y,
time||800
);


});


},



swipe:function(x1,y1,x2,y2,d){


return execute(function(){


swipe(
x1,
y1,
x2,
y2,
d||500
);


});


},



input:function(text){


return execute(function(){


setText(
String(text)
);


});


},



key:function(code){


return execute(function(){


KeyCode(code);


});


}



};



})();


module.exports=ActionEngine;