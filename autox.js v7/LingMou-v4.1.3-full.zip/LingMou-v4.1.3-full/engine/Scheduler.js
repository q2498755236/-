/**
 * 灵眸 v4.1.3
 * Scheduler
 */


var Scheduler=(function(){

"use strict";


var jobs={};

var running=false;

var timer=null;

var index=0;



function createId(){

index++;

return "job_"
+Date.now()
+"_"
+index;

}




function loop(){


if(!running){

return;

}


var now=Date.now();


for(
var id in jobs
){


var job=jobs[id];


if(
job.enabled &&
now-job.lastRun>=job.interval
){


try{


job.running=true;


job.fn();


job.lastRun=now;


}
catch(e){


log(
"[Scheduler]"
+e
);


}
finally{


job.running=false;


}


}



}




return {


init:function(){


log(
"[Scheduler] ready"
);


},



add:function(name,fn,interval){


var id=createId();



jobs[id]={

name:name,

fn:fn,

interval:
interval||1000,

lastRun:0,

enabled:true,

running:false

};


return id;


},



remove:function(id){


delete jobs[id];


},



start:function(){


if(running){

return;

}


running=true;


timer=setInterval(
loop,
50
);


},



stop:function(){


running=false;


if(timer){

clearInterval(timer);

timer=null;

}


},



list:function(){

return jobs;

}



};



})();


module.exports=Scheduler;