/**
 * 灵眸 v4.1.3
 * Main Entry
 * AutoX V7 Rhino
 */

;ui;

(function(){

    "use strict";


    try{


        var Bootstrap =
            require("./core/Bootstrap.js");


        var Compatibility =
            require("./core/Compatibility.js");



        if(!Compatibility.check()){


            throw new Error(
                "Environment check failed"
            );


        }



        Bootstrap.init();


        Bootstrap.start();



        log(
            "[LingMou] v4.1.3 running"
        );



    }
    catch(e){


        log(
            "[LingMou] fatal:"
            +e
        );


        toast(
            "灵眸启动失败"
        );


        exit();


    }



})();