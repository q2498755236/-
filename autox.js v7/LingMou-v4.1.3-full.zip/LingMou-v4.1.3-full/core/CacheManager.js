/**
 * 灵眸 v4.1.3
 * CacheManager
 */


var CacheManager=(function(){

"use strict";


var cache={};

var maxSize=200;



function clean(){


var keys=
Object.keys(cache);



while(
keys.length>maxSize
){

delete cache[
keys.shift()
];


}



}





return {



init:function(){


log(
"[Cache] ready"
);


},




set:function(key,value,ttl){


cache[key]={

value:value,

time:Date.now(),

expire:
ttl?
Date.now()+ttl:
0

};


clean();


},




get:function(key){


var item=
cache[key];


if(!item){

return null;

}



if(
item.expire &&
Date.now()>item.expire
){

delete cache[key];

return null;

}



return item.value;


},



has:function(key){


return this.get(key)!==null;


},



remove:function(key){


delete cache[key];


},



clear:function(){


cache={};


},



size:function(){


return Object.keys(cache)
.length;


}




};



})();


module.exports=CacheManager;