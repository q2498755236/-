/**
 * 灵眸 v4.1.3
 * Compatibility
 */


var Compatibility=(function(){

"use strict";


var result={

passed:false,

checks:{}

};




function check(name,fn){


try{


result.checks[name]=!!fn();


}
catch(e){


result.checks[name]=false;


}



}




return {



init:function(){

return this.check();

},




check:function(){



check(
"auto",
function(){

return typeof auto
!=="undefined";

}

);



check(
"threads",
function(){

return typeof threads
!=="undefined";

}

);



check(
"files",
function(){

return typeof files
!=="undefined";

}

);



check(
"device",
function(){

return typeof device
!=="undefined";

}

);



result.passed=true;



for(
var k in result.checks
){

if(!result.checks[k]){

result.passed=false;

}

}



return result.passed;


},




getResult:function(){

return result;

}




};



})();


module.exports=Compatibility;