/**
 * 灵眸 v4.1.3
 * ConfigManager
 */


var ConfigManager=(function(){

"use strict";


var config={};


var file =
files.join(
    files.cwd(),
    "config/config.json"
);



var DEFAULT={


version:"4.1.3",


debug:false,


logLevel:"info",


thread:{

maxThreads:16,

timeout:30000

},



vision:{

ocr:true

},



ui:{

floaty:true

}


};






function clone(o){

return JSON.parse(
JSON.stringify(o)
);

}




function merge(a,b){


var r=clone(a);


for(var k in b){


if(
typeof b[k]=="object"
&&
!Array.isArray(b[k])
){

r[k]=merge(
r[k]||{},
b[k]
);


}
else{


r[k]=b[k];


}


}


return r;


}






function load(){


if(
files.exists(file)
){


try{


config=
JSON.parse(
files.read(file)
);


}
catch(e){


config=clone(DEFAULT);

}


}
else{


config=clone(DEFAULT);


save();


}



return config;


}





function save(){


files.ensureDir(
files.dirname(file)
);


files.write(
file,
JSON.stringify(
config,
null,
2
)
);


return true;


}






return {


init:function(){

load();

},


load:load,


save:save,


get:function(k){


return config[k];


},



set:function(k,v){


config[k]=v;


save();


},



all:function(){

return config;

}



};


})();


module.exports=ConfigManager;