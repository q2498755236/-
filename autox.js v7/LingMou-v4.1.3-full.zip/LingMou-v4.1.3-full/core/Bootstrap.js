/**
 * 灵眸 v4.1.3
 * Bootstrap
 * 核心启动管理
 */

var Bootstrap = (function(){

    "use strict";


    var state = "idle";

    var modules = {};

    var factories = {};



    function register(name, factory){

        if(typeof factory !== "function"){
            throw new Error(
                "Invalid module:"
                + name
            );
        }

        factories[name]=factory;

    }



    function require(name){

        if(modules[name]){
            return modules[name];
        }


        if(!factories[name]){

            throw new Error(
                "Module missing:"
                +name
            );

        }


        modules[name]=factories[name]();

        return modules[name];

    }




    function init(){


        if(state!=="idle"){
            return false;
        }


        state="initializing";


        try{


            log(
                "[Bootstrap] init"
            );


            state="ready";


            return true;


        }
        catch(e){


            state="error";


            log(
                "[Bootstrap] error:"
                +e
            );


            return false;

        }

    }






    function start(){


        if(
            state!=="ready"
        ){

            if(!init()){

                return false;

            }

        }



        state="running";


        log(
            "[Bootstrap] running"
        );


        return true;


    }








    function stop(){


        for(
            var k in modules
        ){

            try{


                if(
                    modules[k].stop
                ){

                    modules[k].stop();

                }


            }
            catch(e){}



        }


        modules={};


        state="idle";


    }





    return {


        register:register,

        require:require,

        init:init,

        start:start,

        stop:stop,


        state:function(){

            return state;

        }


    };


})();


module.exports=Bootstrap;