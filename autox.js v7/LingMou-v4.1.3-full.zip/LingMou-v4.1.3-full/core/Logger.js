/**
 * 灵眸 v4.1.3
 * Logger
 */


var Logger=(function(){

"use strict";


var file=
files.join(
files.cwd(),
"logs/lingmou.log"
);



function write(level,msg){


var text =
"["
+level
+"] "
+msg
+"\n";



try{


files.append(
file,
text
);


}
catch(e){}



log(text);


}



return {



init:function(){


files.ensureDir(
files.dirname(file)
);


},



debug:function(m){

write(
"DEBUG",
m
);

},



info:function(m){

write(
"INFO",
m
);

},



warn:function(m){

write(
"WARN",
m
);

},



error:function(m){

write(
"ERROR",
m
);

}



};



})();



module.exports=Logger;