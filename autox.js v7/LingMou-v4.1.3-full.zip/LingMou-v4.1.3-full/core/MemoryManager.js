/**
 * 灵眸 v4.1.3
 * MemoryManager
 */


var MemoryManager=(function(){


"use strict";


return {



get:function(){


try{


var r =
java.lang.Runtime
.getRuntime();



return {


total:
r.totalMemory(),


free:
r.freeMemory(),


used:
r.totalMemory()
-
r.freeMemory(),


max:
r.maxMemory()


};



}
catch(e){


return null;


}


},





gc:function(){


try{


java.lang.System.gc();


return true;


}
catch(e){


return false;


}



}



};



})();


module.exports=MemoryManager;