/**
 * 灵眸 v4.1.3
 * ResourceManager
 */


var ResourceManager=(function(){

"use strict";


var images={};

var timers={};

var threads={};



var count=0;



function id(type){

count++;

return type+
"_"+
Date.now()
+
"_"+
count;

}




return {



registerImage:function(img){


var k=id("img");


images[k]={

object:img,

refs:1

};


return k;


},




retainImage:function(k){


if(images[k]){

images[k].refs++;

return true;

}


return false;


},




releaseImage:function(k){


var item=images[k];


if(!item){

return false;

}



item.refs--;



if(item.refs<=0){


try{


if(item.object.recycle){

item.object.recycle();

}


}
catch(e){}



delete images[k];


}



return true;


},





registerTimer:function(t){


var k=id("timer");


timers[k]=t;


return k;


},





registerThread:function(t){


var k=id("thread");


threads[k]=t;


return k;


},





destroy:function(){


for(var k in images){

this.releaseImage(k);

}



for(var t in timers){

try{

clearTimeout(
timers[t]
);

}
catch(e){}


}



for(var th in threads){

try{

threads[th].interrupt();

}
catch(e){}


}



images={};

timers={};

threads={};


}




};



})();


module.exports=ResourceManager;