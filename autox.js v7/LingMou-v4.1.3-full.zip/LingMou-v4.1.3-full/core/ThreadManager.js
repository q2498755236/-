/**
 * 灵眸 v4.1.3
 * ThreadManager
 */

var ThreadManager = (function(){

    "use strict";


    var tasks = {};

    var index = 0;



    function createId(){

        index++;

        return "thread_"
            + Date.now()
            + "_"
            + index;

    }




    return {


        init:function(){

            log(
                "[ThreadManager] ready"
            );

        },



        start:function(name,fn,timeout){


            var id=createId();


            var task={

                id:id,

                name:name,

                start:Date.now(),

                running:true,

                thread:null

            };



            task.thread =
                threads.start(function(){


                    try{

                        fn();


                    }
                    catch(e){


                        log(
                            "[Thread] "
                            +e
                        );


                    }
                    finally{


                        task.running=false;


                    }


                });



            tasks[id]=task;



            if(timeout){


                setTimeout(function(){


                    if(task.running){


                        task.cancel();


                    }


                },timeout);


            }



            return id;


        },





        cancel:function(id){


            var task=
                tasks[id];


            if(!task){

                return false;

            }



            try{


                if(task.thread){
                    task.thread.interrupt();

                }


            }
            catch(e){}



            task.running=false;


            return true;


        },





        stopAll:function(){


            for(var id in tasks){


                this.cancel(id);


            }


            tasks={};


        },





        list:function(){


            return tasks;


        }


    };



})();


module.exports=ThreadManager;