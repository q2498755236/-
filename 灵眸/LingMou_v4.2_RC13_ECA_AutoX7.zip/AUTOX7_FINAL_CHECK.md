# AutoX.js v7 Final Check

处理:
- 全局扫描 JS 文件
- 修复 files.dirName 调用
- 修复 engines.myEngine().source 调用
- 增加 AutoX7Compat

修改文件:
loader.js

状态:
RC11 AutoX7 FinalFix
