# 灵眸 v4.1.6 Event RC3

升级:
- 事件分组：系统/界面/通用/默认
- 事件优先级模型
- EventManager V2
- GUI事件编辑接口预留

事件链:
Scene -> EventGroup -> Event -> Condition -> Action

为后续图形化事件编辑器准备。