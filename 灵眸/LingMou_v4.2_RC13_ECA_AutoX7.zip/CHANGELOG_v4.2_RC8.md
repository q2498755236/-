# LingMou v4.2 RC8

修复:
- AutoX.js 打开显示旧版本问题
- project.json 版本字段错误
- files.dirName 老 API 兼容问题

升级:
- 增加 FileCompat
- 增加 AutoXCompat
- main.js 使用 AutoX.js v7 兼容接口

版本:
4.2.0-rc8
