# LingMou v4.2 RC3

新增:
- 流程运行状态管理
- 流程导入导出
- 节点属性模型
- 运行面板接口

流程:
Editor -> Flow -> Runtime -> Node -> Engine
