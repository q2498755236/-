# 灵眸 v4.1.6 Event RC2

新增:
- Event 与 ConditionEngine 桥接
- Event 与 ActionEngine 桥接
- 事件运行状态接口

目标:
完善事件驱动执行链：

Scene -> Event -> Condition -> Action -> Status