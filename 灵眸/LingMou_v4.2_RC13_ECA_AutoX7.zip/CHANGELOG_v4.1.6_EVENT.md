# 灵眸 v4.1.6 Event Edition

新增:
- SceneManager 界面状态管理
- EventEngine 事件调度基础
- 事件优先级
- 事件冷却机制
- 事件配置模板

目标:
从脚本执行模式向事件驱动自动化模式升级。