# LingMou v4.2 RC11.6 Entry Hardening

修复:
- main.js eval loader 增加异常保护
- 移除 eval 环境下 ;ui; 残留
- 全局版本号统一 v4.2 RC11.6
- 增加启动诊断 BootReport

运行环境:
AutoX.js v7
