# 灵眸 v4.1.3 AutoX.js v7 优化

- ScreenshotManager 增加 withCapture 自动释放接口
- ThreadManager 默认线程上限调整为8
- Scheduler默认tick调整为300ms
- Config同步调整
