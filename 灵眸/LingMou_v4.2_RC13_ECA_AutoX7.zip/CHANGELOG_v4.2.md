# LingMou v4.2 Graphical Event Edition

核心升级:
- 图形化流程数据模型
- 节点系统
- 流程连接模型
- FlowEngine基础运行层
- 图形编辑器接口

支持节点:
- 界面识别
- 条件判断
- 动作执行
- 变量
- 定时器

架构:
Scene -> Event -> Flow -> Condition -> Action