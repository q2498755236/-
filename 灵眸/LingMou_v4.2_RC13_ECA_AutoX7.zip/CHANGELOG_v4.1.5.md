# 灵眸 v4.2 RC11.6

## 优化
- MemoryManager 增加 total/max 双口径内存指标。
- OCREngine 增加结构化 OCR 返回接口 recognizeResult/textResult，区分失败与空结果。
- Logger 支持配置 log directory。
- 保持 AutoX V7 Rhino 兼容。

## 优先级优化
1. 内存指标
2. OCR 错误语义
3. 生命周期与部署配置
